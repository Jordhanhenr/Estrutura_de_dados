package inserção_do_arquivo_AVL;

public class Jogador {
	
	private int id;
	private String nome;
	private String apelido;
	private String nascimento;
	private int altura;
	private float peso;
	
	
	public Jogador(int id, String nome, String apelido, String nascimento, int altura, float peso) {
	
		this.id = id;
		this.nome = nome;
		this.apelido = apelido;
		this.nascimento = nascimento;
		this.altura = altura;
		this.peso = peso;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getApelido() {
		return apelido;
	}
	public void setApelido(String apelido) {
		this.apelido = apelido;
	}
	public String getNascimento() {
		return nascimento;
	}
	public void setNascimento(String nascimento) {
		this.nascimento = nascimento;
	}
	public int getAltura() {
		return altura;
	}
	public void setAltura(int altura) {
		this.altura = altura;
	}
	public float getPeso() {
		return peso;
	}
	public void setPeso(float peso) {
		this.peso = peso;
	}
	@Override
	public String toString() {
		return  String.format("Id: %d\nNome: %s\nApelido: %s\nNascimento: %s\nAltura: %d\nPeso: %f", id,nome,apelido,nascimento,altura,peso);
		
	}

}
