package inserção_do_arquivo_AVL;

import java.util.NoSuchElementException;
import java.security.SecureRandom;
import java.util.Scanner;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.io.FileReader;
import java.io.IOException;


public class LerArquivo {
	
	private Jogador jogador;
	private ArvoreAVL arvore = new ArvoreAVL();

	public Scanner abrirArquivo() {
		Scanner entrada = new Scanner(System.in);
		try {
			entrada = new Scanner(new FileReader("C:\\base_jogadores.csv")).useDelimiter("\\,|\\n");
		}catch(IOException e) {
			System.err.println("Erro ao abrir o arquivo. encerrando aplicativo");
			System.exit(1);
		}
		return entrada;
	}
	public ArvoreAVL getArvore() {
		return arvore;
	}
	
	public void lerArquivo(Scanner entrada) {
		entrada.nextLine();
		
		try {
			while(entrada.hasNext()) {
				arvore.inserir(jogador = new Jogador(Integer.parseInt(entrada.next()),
						entrada.next(),
						entrada.next(),
						entrada.next(),
						Integer.parseInt(entrada.next()), 
						Float.parseFloat(entrada.next())));
			}
		}catch(NoSuchElementException e) {
			System.err.println("Elemento não correspondente");
			System.exit(1);
		}catch(IllegalStateException e) {
			System.err.println("Erro ao tentar ler o arquivo");
			System.exit(1);
		}
		
	}
	public void imprimirArvore() {
		arvore.displayTree();
	}

}
