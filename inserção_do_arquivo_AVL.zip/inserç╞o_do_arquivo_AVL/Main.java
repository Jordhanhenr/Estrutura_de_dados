package inserção_do_arquivo_AVL;

import java.security.SecureRandom;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		LerArquivo arquivo = new LerArquivo();
		entrada = arquivo.abrirArquivo();
		arquivo.lerArquivo(entrada);
		ArvoreAVL arvore = arquivo.getArvore();
		arvore.displayTree();
	}
}
